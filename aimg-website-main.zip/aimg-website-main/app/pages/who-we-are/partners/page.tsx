import React from 'react'
import ComingSoonPage from '../../coming-soon';

export const metadata = {
    title: "Partners | AIMGeneration",
    description:
      "A",
  };
const Partners = () => {
  return (
<ComingSoonPage />
  )
}

export default Partners