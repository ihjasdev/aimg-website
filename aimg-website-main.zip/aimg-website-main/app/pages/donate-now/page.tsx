import React from 'react'

const page = () => {
  return (
    <div>Give your donations here</div>
  )
}

export default page