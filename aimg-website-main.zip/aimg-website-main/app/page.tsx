import HomePage from "@/components/HomePage";
import React from "react";

const page = () => {
  return (
    <div className="min-h-screen">
      <HomePage />
    </div>
  );
};

export default page;
